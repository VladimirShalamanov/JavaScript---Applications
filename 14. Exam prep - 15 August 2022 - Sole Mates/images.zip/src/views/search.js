import { searchItem } from '../api/data.js';
import { html, nothing } from '../lib.js';

let createCard = (s, hasUser) => html`
<ul class="card-wrapper">
    <!-- Display a li with information about every post (if any)-->
    <li class="card">
        <img src=${s.imageUrl} alt="travis" />
    <p>
        <strong>Brand: </strong><span class="brand">${s.brand}</span>
    </p>
    <p>
        <strong>Model: </strong>
        <span class="model">${s.model}</span>
    </p>
        <p><strong>Value:</strong><span class="value">${s.value}</span>$</p>
        ${hasUser ? 
            html`<a class="details-btn" href="/details/${s._id}">Details</a>`
        : nothing}
    </li>
</ul>
`;

let createRes = (subject, hasUser) => {
    if (subject.length == 0) {
        return html`<h2>There are no results found.</h2>`;
    }
    else {
        return html`${subject.map(s => createCard(s, hasUser))}`
    }
};

let template = (isClicked, onSearch, subject, hasUser) => html`
<section id="search">
<h2>Search by Brand</h2>

    <form class="search-wrapper cf">
        <input
            id="#search-input"
            type="text"
            name="search"
            placeholder="Search here..."
            required
        />
        <button @click=${onSearch} type="submit">Search</button>
    </form>

<h3>Results:</h3>

    <div id="search-container">
        ${isClicked ? createRes(subject, hasUser) : nothing}
    </div>
</section>
`;

export async function searchShow(ctx) {
    ctx.render(template(false, onSearch));

    async function onSearch(e) {
        e.preventDefault();
        let searchInput = document.getElementById('#search-input');
        if (!searchInput.value) {
            return alert('Please write a text!')
        }

        let subject = await searchItem(searchInput.value);

        ctx.render(template(true, onSearch, subject, ctx.user));
    }
}