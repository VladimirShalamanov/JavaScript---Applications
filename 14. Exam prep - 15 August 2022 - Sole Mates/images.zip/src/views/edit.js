import { editSubject, getById } from '../api/data.js';
import { html } from '../lib.js';
import { createSubmit } from '../util.js';

// @submit=${onEdit} + .value=${s.name}
let template = (s, onEdit) => html`
<section id="edit">
          <div class="form">
            <h2>Edit item</h2>
            <form @submit=${onEdit} class="edit-form">
              <input
                type="text"
                name="brand"
                id="shoe-brand"
                placeholder="Brand" .value=${s.brand}
              />
              <input
                type="text"
                name="model"
                id="shoe-model"
                placeholder="Model" .value=${s.model}
              />
              <input
                type="text"
                name="imageUrl"
                id="shoe-img"
                placeholder="Image url" .value=${s.imageUrl}
              />
              <input
                type="text"
                name="release"
                id="shoe-release"
                placeholder="Release date" .value=${s.release}
              />
              <input
                type="text"
                name="designer"
                id="shoe-designer"
                placeholder="Designer" .value=${s.designer}
              />
              <input
                type="text"
                name="value"
                id="shoe-value"
                placeholder="Value" .value=${s.value}
              />

              <button type="submit">post</button>
            </form>
          </div>
        </section>
`;

export async function editShow(ctx) {
    let id = ctx.params.id;
    let subject = await getById(id);
    ctx.render(template(subject, createSubmit(onEdit)));

    async function onEdit(d, e) {
        if ([d.brand, d.model, d.imageUrl, d.release, d.designer, d.value].some(x => x == '')) {
            return alert('All fields are required!');
        }
        await editSubject(id, d);
        e.reset();
        ctx.page.redirect(`/details/${id}`);
    }
}