import { getAll } from '../api/data.js';
import { html, nothing } from '../lib.js';

let template = (arr, hasUser) => html`
<section id="dashboard">
          <h2>Collectibles</h2>
          <ul class="card-wrapper">
            <!-- Display a li with information about every post (if any)-->
            
           ${arr.length == 0 ? 
        html`
        <!-- Display an h2 if there are no posts -->
          <h2>There are no items added yet.</h2>`
        : arr.map(a => createCard(a, hasUser))}
          </ul>
</section>
`;

let createCard = (a, hasUser) => html`
<li class="card">
    <img src=${a.imageUrl} alt="travis" />
    <p>
    <strong>Brand: </strong><span class="brand">${a.brand}</span>
    </p>
    <p>
    <strong>Model: </strong
    ><span class="model">${a.model}</span>
    </p>
    <p><strong>Value:</strong><span class="value">${a.value}</span>$</p>
    <a class="details-btn" href="/details/${a._id}">Details</a>
</li>
`;

export async function catalogShow(ctx) {
    let arr = await getAll();

    ctx.render(template(arr, ctx.user));
}