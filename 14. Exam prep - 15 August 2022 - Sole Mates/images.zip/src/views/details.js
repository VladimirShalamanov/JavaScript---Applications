import { delById, getById } from '../api/data.js';
import { html, nothing } from '../lib.js';

// @click=${onDelete}
let template = (s, isOwner, onDelete) => html`
<section id="details">
          <div id="details-wrapper">
            <p id="details-title">Shoe Details</p>
            <div id="img-wrapper">
              <img src=${s.imageUrl} alt="example1" />
            </div>
            <div id="info-wrapper">
              <p>Brand: <span id="details-brand">${s.brand}</span></p>
              <p>
                Model: <span id="details-model">${s.model}</span>
              </p>
              <p>Release date: <span id="details-release">${s.release}</span></p>
              <p>Designer: <span id="details-designer">${s.designer}</span></p>
              <p>Value: <span id="details-value">${s.value}</span></p>
            </div>
            ${isOwner ? html`
            <!--Edit and Delete are only for creator-->
            <div id="action-buttons">
              <a href="/edit/${s._id}" id="edit-btn">Edit</a>
              <a @click=${onDelete} href="javascript:void(0)" id="delete-btn">Delete</a>
            </div>
            ` : nothing}
          </div>
        </section>
`;

// function control(pet, hasUser, canDonate, isOwner, onDelete, onDonate) {
//     if (hasUser == false) {
//         return '';
//     }
//     if (canDonate) {
//         return html`
//         <div class="actionBtn">
//             <a @click=${onDonate} href="javascript:void(0)" class="donate">Donate</a>
//         </div>`;
//     }
//     if (isOwner) {
//         return html`
//         <div class="actionBtn">
//             <a href="/edit/${pet._id}" class="edit">Edit</a>
//             <a @click=${onDelete} href="javascript:void(0)" class="remove">Delete</a>
//         </div>`;
//     }
// }

export async function detailsShow(ctx) {
    let id = ctx.params.id;
    let subject = await getById(id);
    let isOwner = subject._ownerId === ctx.user._id;

    ctx.render(template(subject, isOwner, onDelete));

    // let requests = [
    //     getById(id),
    //     getDonation(id)
    // ];

    // let hasUser = Boolean(ctx.user);
    // if (hasUser) {
    //     requests.push(getOwnDonation(id, ctx.user._id));
    // }
    // let [pet, donations, hasDonation] = await Promise.all(requests);

    // let isOwner = hasUser && ctx.user._id == pet._ownerId;
    // let canDonate = !isOwner && hasDonation == 0;

    async function onDelete() {
        let choice = confirm('Are you sure you want to delete it?');

        if (choice) {
            await delById(id);
            ctx.page.redirect('/catalog');
        }
    }

    // async function onDonate() {
    //     await donate(id);
    //     ctx.page.redirect('/catalog/' + id);
    // }
}