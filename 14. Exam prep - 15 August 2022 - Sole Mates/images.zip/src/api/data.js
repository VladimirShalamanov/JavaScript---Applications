import { get, post, put, del } from "./api.js";

export async function getAll(){
    return get('/data/shoes?sortBy=_createdOn%20desc');
}

export async function getById(id){
    return get('/data/shoes/' + id);
}

export async function delById(id){
    return del('/data/shoes/' + id);
}

export async function createSubject(data){
    return post('/data/shoes', data);
}

export async function editSubject(id, data){
    return put('/data/shoes/' + id, data);
}

//------
export async function searchItem(query){
    return get(`/data/shoes?where=brand%20LIKE%20%22${query}%22`);
}