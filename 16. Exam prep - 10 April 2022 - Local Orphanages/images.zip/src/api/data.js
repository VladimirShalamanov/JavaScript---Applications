import { get, post, put, del } from "./api.js";

export async function getAll() {
    return get('/data/posts?sortBy=_createdOn%20desc');
}

export async function getById(id) {
    return get('/data/posts/' + id);
}

export async function delById(id) {
    return del(`/data/posts/${id}`);
}

export async function createSubject(data) {
    return post('/data/posts', data);
}

export async function editSubject(id, data) {
    return put('/data/posts/' + id, data);
}

//--------------------------------------------------------------

export async function getMyPosts(userId) {
    return get(`/data/posts?where=_ownerId%3D%22${userId}%22&sortBy=_createdOn%20desc`);
}

export async function makeDonation(data) {
    return post('/data/donations', data);
}

export async function getTotalDonations(postId) {
    return get(`/data/donations?where=postId%3D%22${postId}%22&distinct=_ownerId&count`);
}

export async function hasDonated(postId, userId) {
    return get(`/data/donations?where=postId%3D%22${postId}%22%20and%20_ownerId%3D%22${userId}%22&count`);
}