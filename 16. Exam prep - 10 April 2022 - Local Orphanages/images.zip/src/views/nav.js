import { logout } from "../api/users.js";
import { html, render, page } from "../lib.js";
import { getUserData } from "../util.js";

let nav = document.querySelector('header');

let navTemp = (hasUser) => html`
<!-- Navigation -->
            <h1><a href="/">Orphelp</a></h1>

            <nav>
                <a href="/">Dashboard</a>
                ${hasUser ? html`
                <!-- Logged-in users -->
                <div id="user">
                    <a href="/myposts">My Posts</a>
                    <a href="/create">Create Post</a>
                    <a @click=${onLogout} href="javascript:void(0)">Logout</a>
                </div>`
        : html`
                <!-- Guest users -->
                <div id="guest">
                    <a href="/login">Login</a>
                    <a href="/register">Register</a>
                </div>
                `}
            </nav>
`;

export function updateNav() {
    let user = getUserData();

    render(navTemp(user), nav);
}

function onLogout() {
    logout();
    updateNav();
    page.redirect('/catalog');
}