import { editSubject, getById } from '../api/data.js';
import { html } from '../lib.js';
import { createSubmit } from '../util.js';

//  @submit=${onEdit} +  .value=${s.name}
let template = (s, onEdit) => html`
<section id="edit-page" class="auth">
            <form @submit=${onEdit} id="edit">
                <h1 class="title">Edit Post</h1>

                <article class="input-group">
                    <label for="title">Post Title</label>
                    <input type="title" name="title" id="title" value=${s.title}>
                </article>

                <article class="input-group">
                    <label for="description">Description of the needs </label>
                    <input type="text" name="description" id="description" value=${s.description}>
                </article>

                <article class="input-group">
                    <label for="imageUrl"> Needed materials image </label>
                    <input type="text" name="imageUrl" id="imageUrl" value=${s.imageUrl}>
                </article>

                <article class="input-group">
                    <label for="address">Address of the orphanage</label>
                    <input type="text" name="address" id="address" value=${s.address}>
                </article>

                <article class="input-group">
                    <label for="phone">Phone number of orphanage employee</label>
                    <input type="text" name="phone" id="phone" value=${s.phone}>
                </article>

                <input type="submit" class="btn submit" value="Edit Post">
            </form>
        </section>
`;

export async function editShow(ctx) {
    let id = ctx.params.id;
    let subject = await getById(id);
    ctx.render(template(subject, createSubmit(onEdit)));

    async function onEdit(d, e) {
        if ([d.title, d.description, d.imageUrl, d.address, d.phone].some(x => x == '')) {
            return alert('All fields are required!');
        }
        
        await editSubject(id, d);
        e.reset();
        ctx.page.redirect(`/details/${id}`);
    }
}