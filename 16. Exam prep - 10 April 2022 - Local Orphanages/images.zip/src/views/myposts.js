import { getMyPosts } from "../api/data.js";
import { html, nothing } from '../lib.js';

let template = (arr, hasUser) => html`
<section id="my-posts-page">
            <h1 class="title">My Posts</h1>
            
            <!-- Display a div with information about every post (if any)-->
            <!-- Display an h1 if there are no posts -->
            
            <div class="my-posts">

            ${arr.length > 0 ? 
                arr.map(a => createCard(a))
                :
                html`<h1 class="title no-posts-title">You have no posts yet!</h1>>`}
                
            </div>

</section>
`;

let createCard = (a) => html`
    <div class="post">
        <h2 class="post-title">${a.title}</h2>
            <img class="post-image" src=${a.imageUrl} alt="Material Image">
        <div class="btn-wrapper">
            <a href="/details/${a._id}" class="details-btn btn">Details</a>
        </div>
    </div>
`;

export async function myPostsShow(ctx) {
    let arr = await getMyPosts(ctx.user._id);

    ctx.render(template(arr, ctx.user));
}