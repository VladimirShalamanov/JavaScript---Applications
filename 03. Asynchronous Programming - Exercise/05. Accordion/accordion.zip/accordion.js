// async function solution() {
//     const main = document.getElementById('main');
//     main.innerHTML = '';
//     let url = 'http://localhost:3030/jsonstore/advanced/articles/list';
//     let response = await fetch(url);
//     let data = await response.json();

//     data.forEach(x => {

//         let div1 = document.createElement('div');
//         div1.classList.add('accordion');

//         let div2 = document.createElement('div');
//         div2.classList.add('head');
//         let span = document.createElement('span');
//         span.textContent = x.title;
//         let btn = document.createElement('buton');
//         btn.classList.add('button');
//         btn.id = x._id;
//         btn.textContent = 'More';

//         div2.appendChild(span);
//         div2.appendChild(btn);

//         let div3 = document.createElement('div');
//         div3.classList.add('extra');
//         let p = document.createElement('p');
//         div3.appendChild(p);
//         div3.style.display = 'none';


//         div1.appendChild(div2);
//         div1.appendChild(div3);
//         main.appendChild(div1);

//         btn.addEventListener('click', async () => {
//             if (div3.style.display === 'none') {
//                 const da = await fetch(`http://localhost:3030/jsonstore/advanced/articles/details/${x._id}`)
//                 const desData = await da.json()
//                 btn.textContent = 'Less'
//                 div3.style.display = 'block'
//                 p.textContent = desData.content
//             } else {
//                 btn.textContent = 'More'
//                 div3.style.display = 'none'
//             }
//         });
//     });
// }
// document.addEventListener('DOMContentLoaded', solution)
async function solution () {
	const output = document.getElementById('main')
	const titles = await fetch('http://localhost:3030/jsonstore/advanced/articles/list')
	const desTitles = await titles.json()

	desTitles.forEach(x => output.appendChild(template(x)))
}
function template ({ _id, title }) {
	const wrapper = eFactory('div', 'accordion')
	const headDiv = eFactory('div', 'head')
	const titleSpan = eFactory('span', '', title)
	const btn = eFactory('button', 'button', 'More')
	const extraDiv = eFactory('div', 'extra')
	extraDiv.style.display = 'none'
	const contentParagraph = eFactory('p')
	btn.id = _id

	headDiv.append(titleSpan, btn)
	extraDiv.appendChild(contentParagraph)
	wrapper.append(headDiv, extraDiv)

	btn.addEventListener('click', async () => {
		if (extraDiv.style.display === 'none') {
			const data = await fetch(`http://localhost:3030/jsonstore/advanced/articles/details/${_id}`)
			const desData = await data.json()
			btn.textContent = 'Less'
			extraDiv.style.display = 'block'
			contentParagraph.textContent = desData.content
		} else {
			btn.textContent = 'More'
			extraDiv.style.display = 'none'
		}
	})

	return wrapper
}
function eFactory (tag, className = '', content = '') {
	const e = document.createElement(tag)
	e.className = className
	e.textContent = content

	return e
}

document.addEventListener('DOMContentLoaded', solution)