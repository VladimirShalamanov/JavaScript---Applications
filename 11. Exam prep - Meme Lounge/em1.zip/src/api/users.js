import { get, post } from "./api.js";
import { clearUserData, setUserData } from "../util.js";

export async function login(email, password) {
    let res = await post('/users/login', { email, password });
    let userData = {
        id: res._id,
        username: res.username,
        email: res.email,
        gender: res.gender,
        accessToken: res.accessToken
    };

    setUserData(userData);
    return res;
}

export async function register(username, email, password, gender) {
    let res = await post('/users/register', { username, email, password, gender });
    let userData = {
        id: res._id,
        username: res.username,
        email: res.email,
        gender: res.gender,
        accessToken: res.accessToken
    };

    setUserData(userData);
    return res;
}

export function logout() {
    get('/users/logout');
    clearUserData();
}