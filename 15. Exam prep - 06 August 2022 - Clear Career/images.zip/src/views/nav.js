import { logout } from "../api/users.js";
import { html, render, page } from "../lib.js";
import { getUserData } from "../util.js";

let nav = document.querySelector('header');

let navTemp = (hasUser) => html`
<!-- Navigation -->
        <a id="logo" href="/"
          ><img id="logo-img" src="./images/logo.jpg" alt=""
        /></a>

        <nav>
          <div>
            <a href="/catalog">Dashboard</a>
          </div>
          ${hasUser ? html`
          <!-- Logged-in users -->
          <div class="user">
            <a href="/create">Create Offer</a>
            <a @click=${onLogout} href="javascript:void(0)">Logout</a>
          </div>`
          : html`
          <!-- Guest users -->
          <div class="guest">
            <a href="/login">Login</a>
            <a href="/register">Register</a>
          </div>
        </nav>
          `}
`;

export function updateNav() {
    let user = getUserData();

    render(navTemp(user), nav);
}

function onLogout() {
    logout();
    updateNav();
    page.redirect('/catalog');
}