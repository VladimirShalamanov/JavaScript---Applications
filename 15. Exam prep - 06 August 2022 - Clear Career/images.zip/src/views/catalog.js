import { getAll } from '../api/data.js';
import { html, nothing } from '../lib.js';

let template = (arr, hasUser) => html`
<section id="dashboard">
    <h2>Job Offers</h2>

    <!-- Display a div with information about every post (if any)-->
    <!-- Display an h2 if there are no posts -->

              ${arr.length > 0 ? 
                arr.map(a => createCard(a))
              :
              html`<h2>No offers yet.</h2>`}

</section>
`;

let createCard = (a) => html`
<div class="offer">
  <img src=${a.imageUrl} alt="example1" />
  <p>
    <strong>Title: </strong><span class="title">${a.title}</span>
  </p>
  <p><strong>Salary:</strong><span class="salary">${a.salary}</span></p>
  <a class="details-btn" href="/details/${a._id}">Details</a>
</div>
`;

export async function catalogShow(ctx) {
    let arr = await getAll();

    ctx.render(template(arr, ctx.user));
}