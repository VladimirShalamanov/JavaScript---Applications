import { delById, getById, addItem, getTotalItems, userAdded } from '../api/data.js';
import { html, nothing } from '../lib.js';

// @click=${onDelete}
let template = (s, hasUser, isOwner, onDelete,
  totalApp, userApply, onApplication) => html`
<section id="details">
          <div id="details-wrapper">
            <img id="details-img" src=${s.imageUrl} alt="example1" />
            <p id="details-title">Senior Frontend Software Engineer</p>
            <p id="details-category">
              Category: <span id="categories">${s.category}</span>
            </p>
            <p id="details-salary">
              Salary: <span id="salary-number">${s.salary}</span>
            </p>
            <div id="info-wrapper">
              <div id="details-description">
                <h4>Description</h4>
                <span>${s.description}</span>
              </div>
              <div id="details-requirements">
                <h4>Requirements</h4>
                <span>${s.requirements}</span>
              </div>
            </div>
            <p>Applications: <strong id="applications">${totalApp}</strong></p>

                  <!--Edit and Delete are only for creator-->
                  <!--Bonus - Only for logged-in users ( not authors )-->
                  ${controlButtons(s, hasUser, isOwner, onDelete,
    totalApp, userApply, onApplication)}
            
          </div>
</section>
            `;

function controlButtons(s, hasUser, isOwner, onDelete,
  totalApp, userApply, onApplication) {
  if (isOwner) {
    return html`
            <div id="action-buttons">
                <a href="/edit/${s._id}" id="edit-btn">Edit</a>
                <a @click=${onDelete} href="javascript:void(0)" id="delete-btn">Delete</a>
            </div>`;
  }
  if (hasUser && userApply == 0) {
    return html`
            <div id="action-buttons">
                <a @click=${onApplication} href="javascript:void(0)" id="apply-btn">Apply</a>
            </div>`;
  }
}

export async function detailsShow(ctx) {
  let id = ctx.params.id;
  let subject = await getById(id);
  
  let userApply;
  let userId;
  if (ctx.user) {
    userId = ctx.user._id;
    userApply = await userAdded(id, userId);
  }

  let isOwner = ctx.user && subject._ownerId === ctx.user._id;
  let totalApp = await getTotalItems(id);

  ctx.render(template(subject, ctx.user, isOwner, onDelete,
    totalApp, userApply, onApplication));

  async function onApplication() {
    const donation = {
      id,
    };
    await addItem(donation);

    totalApp = await getTotalItems(id);
    userApply = await userAdded(id, userId);

    ctx.render(template(subject, ctx.user, isOwner, onDelete,
      totalApp, userAdded, onApplication));
  }

  async function onDelete() {
    let choice = confirm('Are you sure you want to delete it?');

    if (choice) {
      await delById(id);
      ctx.page.redirect('/catalog');
    }
  }

  // async function onDonate() {
  //     await donate(id);
  //     ctx.page.redirect('/catalog/' + id);
  // }
}