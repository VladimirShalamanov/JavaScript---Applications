import { get, post, put, del } from "./api.js";

export async function getAll() {
    return get('/data/games?sortBy=_createdOn%20desc');
}

export async function getAllForHome() {
    return get('/data/games?sortBy=_createdOn%20desc&distinct=category');
}

export async function getById(id) {
    return get(`/data/games/${id}`);
}

export async function delById(id) {
    return del(`/data/games/${id}`);
}

export async function createSubject(data) {
    return post('/data/games', data);
}

export async function editSubject(id, data) {
    return put(`/data/games/${id}`, data);
}

//--------------------------------------------------------------

export async function addData(gameId, comment) {
    return post('/data/comments', { gameId, comment });
}

export async function getTotalData(gameId) {
    return get(`/data/comments?where=gameId%3D%22${gameId}%22`);
}

// export async function hasAdded(offerId, userId) {
//     return get(`/data/applications?where=offerId%3D%22${offerId}%22%20and%20_ownerId%3D%22${userId}%22&count`);
// }