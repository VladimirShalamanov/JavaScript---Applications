import { getAll } from '../api/data.js';
import { html, nothing } from '../lib.js';

let template = (arr) => html`
<section id="catalog-page">
    <h1>All Games</h1>
    ${arr.length == 0 ?
    html` <h3 class="no-articles">No articles yet</h3>`
    : arr.map(a => html`
      <div class="allGames">
          <div class="allGames-info">
              <img src=${a.imageUrl}>
              <h6>${a.category}</h6>
              <h2>${a.title}</h2>
              <a href="/details/${a._id}" class="details-button">Details</a>
          </div>
      </div>`)}
</section>
`;

export async function catalogShow(ctx) {
  let arr = await getAll();
  ctx.render(template(arr));
}