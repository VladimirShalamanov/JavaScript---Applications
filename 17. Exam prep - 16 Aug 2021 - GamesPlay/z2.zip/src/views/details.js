import { delById, getById, addData, getTotalData } from '../api/data.js';
import { html, nothing } from '../lib.js';
import { createSubmit } from '../util.js';

// @click=${onDelete}   javascript:void(0)
let template = (s, hasUser, isOwner, onDelete, comments, onComment) => html`
<section id="game-details">
  <h1>Game Details</h1>
  <div class="info-section">

      <div class="game-header">
          <img class="game-img" src=${s.imageUrl} />
          <h1>${s.title}</h1>
          <span class="levels">MaxLevel: ${s.maxLevel}</span>
          <p class="type">${s.category}</p>
      </div>

      <p class="text">${s.summary}</p>

      <!-- Bonus ( for Guests and Users ) -->
      <div class="details-comments">
          <h2>Comments:</h2>
          <ul>
          <!-- list all comments for current game (If any) -->
          ${comments == 0 ?
    html`<p class="no-comment">No comments.</p>`
    : comments.map(c => html`
              <li class="comment">
                <p>Content: ${c.comment}</p>
              </li>`)}
          </ul>
              <!-- Display paragraph: If there are no games in the database -->
      </div>

      ${isOwner ?
    html`<div class="buttons">
              <a href="/edit/${s._id}" class="button">Edit</a>
              <a @click=${onDelete} href="javascript:void(0)" class="button">Delete</a>
          </div>` : nothing}
  </div>

  <!-- Bonus -->
  <!-- Add Comment ( Only for logged-in users, which is not creators of the current game ) -->
       ${hasUser && !isOwner ?
    html`
              <article class="create-comment">
                  <label>Add new comment:</label>
                  <form @submit=${onComment} class="form">
                      <textarea name="comment" placeholder="Comment......"></textarea>
                      <input class="btn submit" type="submit" value="Add Comment">
                  </form>
              </article>`
    : nothing}
</section>
`;

export async function detailsShow(ctx) {
  let id = ctx.params.id;
  let subject = await getById(id);
  let isOwner = ctx.user && subject._ownerId === ctx.user._id;

  let comments = await getTotalData(id);

  ctx.render(template(subject, ctx.user, isOwner, onDelete, comments, createSubmit(onComment)));

  async function onDelete() {
    let choice = confirm('Are you sure you want to delete it?');

    if (choice) {
      await delById(id);
      ctx.page.redirect('/');
    }
  }

  async function onComment(data, e) {
    if (!data.comment) {
      return alert('Field is required!');
    }
    await addData(id, data.comment);
    comments = await getTotalData(id);
    ctx.render(template(subject, ctx.user, isOwner, onDelete, comments, createSubmit(onComment)));
    e.reset();
    ctx.page.redirect(`/details/${id}`);
  }
}