import { editSubject, getById } from '../api/data.js';
import { html } from '../lib.js';
import { createSubmit } from '../util.js';

// @submit=${onEdit} +  .value=${s.name}
let template = (s, onEdit) => html`
<section id="edit-page" class="auth">
    <form @submit=${onEdit} id="edit">
        <div class="container">

            <h1>Edit Game</h1>
            <label for="leg-title">Legendary title:</label>
            <input type="text" id="title" name="title" .value=${s.title}>

            <label for="category">Category:</label>
            <input type="text" id="category" name="category" .value=${s.category}>

            <label for="levels">MaxLevel:</label>
            <input type="number" id="maxLevel" name="maxLevel" min="1" .value=${s.maxLevel}>

            <label for="game-img">Image:</label>
            <input type="text" id="imageUrl" name="imageUrl" .value=${s.imageUrl}>

            <label for="summary">Summary:</label>
            <textarea name="summary" id="summary">${s.summary}</textarea>
            <input class="btn submit" type="submit" value="Edit Game">

        </div>
    </form>
</section>
`;

export async function editShow(ctx) {
  let id = ctx.params.id;
  let subject = await getById(id);
  ctx.render(template(subject, createSubmit(onEdit)));

  async function onEdit(data, e) {
    if (Object.values(data).some(x => !x)) {
      return alert('All fields are required!')
    }
    
    await editSubject(id, data);
    e.reset();
    ctx.page.redirect(`/details/${id}`);
  }
}