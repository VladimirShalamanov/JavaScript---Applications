import { getAll } from '../api/data.js';
import { html, nothing } from '../lib.js';

let template = (arr) => html`
<section id="dashboard">
        <h2>Albums</h2>
        <ul class="card-wrapper">
        <!-- Display an h2 if there are no posts -->
        <!-- Display a li with information about every post (if any)-->
        ${arr.length == 0 ?
          html`<h2>There are no albums added yet.</h2>`
          : arr.map(a => html`
              <li class="card">
                <img src=${a.imageUrl} alt="travis" />
                <p>
                  <strong>Singer/Band: </strong><span class="singer">${a.singer}</span>
                </p>
                <p>
                  <strong>Album name: </strong><span class="album">${a.album}</span>
                </p>
                <p><strong>Sales:</strong><span class="sales">${a.sales}</span></p>
                <a class="details-btn" href="/details/${a._id}">Details</a>
              </li>`
          )}
        </ul>
        
</section>
`;

export async function catalogShow(ctx) {
  let arr = await getAll();

  ctx.render(template(arr));
}