import { editSubject, getById } from '../api/data.js';
import { html } from '../lib.js';
import { createSubmit } from '../util.js';

let template = (s, onEdit) => html`
<section id="edit">
        <div class="form">
          <h2>Edit Album</h2>
          <form @submit=${onEdit} class="edit-form">
            <input type="text" name="singer" id="album-singer" placeholder="Singer/Band" .value=${s.singer} />
            <input type="text" name="album" id="album-album" placeholder="Album" .value=${s.album} />
            <input type="text" name="imageUrl" id="album-img" placeholder="Image url" .value=${s.imageUrl} />
            <input type="text" name="release" id="album-release" placeholder="Release date" .value=${s.release} />
            <input type="text" name="label" id="album-label" placeholder="Label" .value=${s.label} />
            <input type="text" name="sales" id="album-sales" placeholder="Sales" .value=${s.sales} />

            <button type="submit">post</button>
          </form>
        </div>
</section>
`;

export async function editShow(ctx) {
  let id = ctx.params.id;
  let subject = await getById(id);
  ctx.render(template(subject, createSubmit(onEdit)));

  async function onEdit(data, e) {
    if (Object.values(data).some(x => !x)) {
      return alert('All fields are required!')
    }
    
    await editSubject(id, data);
    e.reset();
    ctx.page.redirect(`/details/${id}`);
  }
}