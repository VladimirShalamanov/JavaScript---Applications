import { delById, getById, addData, getTotalData, hasClicked } from '../api/data.js';
import { html, nothing } from '../lib.js';
import { createSubmit } from '../util.js';

let template = (s, hasUser, isOwner, onDelete, likes, clicked, onLike) => html`
<section id="details">
        <div id="details-wrapper">
          <p id="details-title">Album Details</p>
          <div id="img-wrapper">
            <img src=${s.imageUrl} alt="example1" />
          </div>
          <div id="info-wrapper">
            <p><strong>Band:</strong><span id="details-singer">${s.singer}</span></p>
            <p>
              <strong>Album name:</strong><span id="details-album">${s.album}</span>
            </p>
            <p><strong>Release date:</strong><span id="details-release">${s.release}</span></p>
            <p><strong>Label:</strong><span id="details-label">${s.label}</span></p>
            <p><strong>Sales:</strong><span id="details-sales">${s.sales}</span></p>
          </div>
          <div id="likes">Likes: <span id="likes-count">${likes}</span></div>
        ${isOwner ? html`
          <div id="action-buttons">
                <a href="/edit/${s._id}" id="edit-btn">Edit</a>
                <a @click=${onDelete} href="javascript:void(0)" id="delete-btn">Delete</a>
              </div>` : nothing }
        ${!isOwner && hasUser && clicked == 0 ? html`
          <div id="action-buttons">
                <a @click=${onLike} href="javascript:void(0)" id="like-btn">Like</a>
          </div>` : nothing }
        </div>
      </section>
`;

export async function detailsShow(ctx) {
  let id = ctx.params.id;
  let subject = await getById(id);
  let isOwner = ctx.user && subject._ownerId === ctx.user._id;

  let likes = await getTotalData(id);

  let clicked;
  if (ctx.user){
    clicked = await hasClicked(id, ctx.user._id);
  } 
  
  ctx.render(template(subject, ctx.user, isOwner, onDelete, likes, clicked, onLike));

  async function onDelete() {
    let choice = confirm('Are you sure you want to delete it?');

    if (choice) {
      await delById(id);
      ctx.page.redirect('/catalog');
    }
  }

  async function onLike() {
    await addData(id);
    likes = await getTotalData(id);
    clicked = await hasClicked(id, ctx.user._id);
    ctx.render(template(subject, ctx.user, isOwner, onDelete, likes, clicked, onLike));
  }
}