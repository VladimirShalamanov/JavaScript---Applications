import { logout } from "../api/users.js";
import { html, render, page } from "../lib.js";
import { getUserData } from "../util.js";

let nav = document.querySelector('header');

let navTemp = (hasUser) => html`
<nav>
    <section class="logo">
        <img src="/images/logo.png" alt="logo">
    </section>
    <ul>
        <!--Users and Guest-->
        <li><a href="/">Home</a></li>
        <li><a href="/catalog">Dashboard</a></li>
        ${!hasUser ? 
        html`<li><a class="guest" href="/login">Login</a></li>
        <li><a class="guest" href="/register">Register</a></li>`
        : 
        html`<li><a class="user" href="/create">Create Postcard</a></li>
        <li><a @click=${onLogout} class="user" id="logoutBtn" href="javascript:void(0)">Logout</a></li>
        `}
        <!--Only Users-->
        <!--Only Guest-->
    </ul>
</nav>
`;

export function updateNav(){
    let user = getUserData();
    render(navTemp(user), nav);
}

function onLogout(e){
    logout();
    updateNav();
    page.redirect('/');
}