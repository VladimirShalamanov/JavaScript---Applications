import { getUserData, clearUserData } from "../util.js";

let host = 'http://localhost:3030';


async function request(method, url, data) {
    let options = {
        method,
        headers: {}
    };

    if (data) {
        options.headers['Content-Type'] = 'application/json';
        options.body = JSON.stringify(data);
    }

    let userData = getUserData();
    if (userData) {
        options.headers['X-Authorization'] = userData.accessToken;
    }
    try {
        let res = await fetch(host + url, options);

        if (!res.ok) {
            if (res.status == 403) {
                clearUserData();
            }
            let error = await res.json();
            throw new Error(error.message);
        }

        if (res.status == 204) {
            return res;
        }
        else {
            return res.json();
        }
    }
    catch (err) {
        alert(err.message);
        throw err;
    }
}

export const get = request.bind(null, 'get');
export const post = request.bind(null, 'post');
export const put = request.bind(null, 'put');
export const del = request.bind(null, 'delete');