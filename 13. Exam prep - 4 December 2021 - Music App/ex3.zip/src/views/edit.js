import { editSubject, getById } from '../api/data.js';
import { html } from '../lib.js';
import { createSubmit } from '../util.js';

// @submit=${onEdit} + .value=${s.name}
let template = (s, onEdit) => html`
<section class="editPage">
            <form @submit=${onEdit}>
                <fieldset>
                    <legend>Edit Album</legend>

                    <div class="container">
                        <label for="name" class="vhide">Album name</label>
                        <input id="name" name="name" class="name" type="text" .value=${s.name}>

                        <label for="imgUrl" class="vhide">Image Url</label>
                        <input id="imgUrl" name="imgUrl" class="imgUrl" type="text" .value=${s.imgUrl}>

                        <label for="price" class="vhide">Price</label>
                        <input id="price" name="price" class="price" type="text" .value=${s.price}>

                        <label for="releaseDate" class="vhide">Release date</label>
                        <input id="releaseDate" name="releaseDate" class="releaseDate" type="text" .value=${s.releaseDate}>

                        <label for="artist" class="vhide">Artist</label>
                        <input id="artist" name="artist" class="artist" type="text" .value=${s.artist}>

                        <label for="genre" class="vhide">Genre</label>
                        <input id="genre" name="genre" class="genre" type="text" .value=${s.genre}>

                        <label for="description" class="vhide">Description</label>
                        <textarea name="description" class="description" rows="10"
                            cols="10">${s.description}</textarea>

                        <button class="edit-album" type="submit">Edit Album</button>
                    </div>
                </fieldset>
            </form>
        </section>
`;

export async function editShow(ctx) {
    let id = ctx.params.id;
    let subject = await getById(id);
    ctx.render(template(subject, createSubmit(onEdit)));

    async function onEdit(d, e) {
        if ([d.name, d.imgUrl, d.price, d.releaseDate, d.artist, d.genre, d.description].some(x => x == '')) {
            return alert('All fields are required!');
        }
        await editSubject(id, d);
        e.reset();
        ctx.page.redirect(`/details/${id}`);
    }
}