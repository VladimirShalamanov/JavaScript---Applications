import { searchItem } from '../api/data.js';
import { html, nothing } from '../lib.js';

let template = (isClicked, onSearch, subject, hasUser) => html`
<section id="searchPage">
    <h1>Search by Name</h1>

    <div class="search">
        <input id="search-input" type="text" name="search" placeholder="Enter desired albums's name">
        <button @click=${onSearch} class="button-list">Search</button>
    </div>

    <h2>Results:</h2>
    <div class="search-result">
        ${isClicked ? createRes(subject, hasUser) : nothing}
    </div>
</section>
`;

let createRes = (subject, hasUser) => {
    return html`
    ${subject.length > 0 ?
            html`${subject.map(s => createCard(s, hasUser))}`
            : html`<p class="no-result">No result.</p>`}`;
};

let createCard = (s, hasUser) => html`
<!--If have matches-->
    <div class="card-box">
        <img src=${s.imgUrl}>
        <div>
            <div class="text-center">
                <p class="name">Name: ${s.name}</p>
                <p class="artist">Artist: ${s.artist}</p>
                <p class="genre">Genre: ${s.genre}</p>
                <p class="price">Price: $${s.price}</p>
                <p class="date">Release Date: ${s.date}</p>
            </div>
            ${hasUser ? html`
            <div class="btn-group">
            <a href="/details/${s._id}" id="details">Details</a>
            </div>
            `
        : nothing}
        </div>`;

export async function searchShow(ctx) {
    ctx.render(template(false, onSearch));

    async function onSearch(e) {
        let searchInput = document.getElementById('search-input');
        if (!searchInput.value) {
            return alert('Please write a text!')
        }

        let subject = await searchItem(searchInput.value);

        ctx.render(template(true, onSearch, subject, ctx.user));
    }
}