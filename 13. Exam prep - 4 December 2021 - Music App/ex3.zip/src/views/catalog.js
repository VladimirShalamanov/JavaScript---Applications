import { getAll } from '../api/data.js';
import { html, nothing } from '../lib.js';

let template = (arr, hasUser) => html`
<section id="catalogPage">
            <h1>All Albums</h1>
            <!--No albums in catalog-->
            ${arr.length == 0 ?
        html`
                <p>No Albums in Catalog!</p>`
        :
        arr.map(a => createCard(a, hasUser))}

        </section>
`;

let createCard = (a, hasUser) => html`
<div class="card-box">
                <img src=${a.imgUrl}>
                <div>
                    <div class="text-center">
                        <p class="name">Name: ${a.name}</p>
                        <p class="artist">Artist: ${a.artist}</p>
                        <p class="genre">Genre: ${a.genre}</p>
                        <p class="price">Price: $${a.price}</p>
                        <p class="date">Release Date: ${a.releaseDate}</p>
                    </div>

                    ${hasUser ? html`
                        <div class="btn-group">
                            <a href="/details/${a._id}" id="details">Details</a>
                        </div>`
                        :
                        nothing
                    }
                </div>
            </div>
`;

export async function catalogShow(ctx) {
    let arr = await getAll();

    ctx.render(template(arr, ctx.user));
}