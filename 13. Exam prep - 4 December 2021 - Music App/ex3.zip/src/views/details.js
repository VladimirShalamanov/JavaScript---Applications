import { delById, getById } from '../api/data.js';
import { html, nothing } from '../lib.js';

let template = (s, isOwner, onDelete) => html`
<section id="detailsPage">
            <div class="wrapper">
                <div class="albumCover">
                    <img src=${s.imgUrl}>
                </div>
                <div class="albumInfo">
                    <div class="albumText">

                        <h1>Name: ${s.name}</h1>
                        <h3>Artist: ${s.artist}</h3>
                        <h4>Genre: ${s.genre}</h4>
                        <h4>Price: $${s.price}</h4>
                        <h4>Date: ${s.releaseDate}</h4>
                        <p>Description: ${s.description}</p>
                    </div>

                    <!-- Only for registered user and creator of the album-->
                    ${isOwner ? html`
                        <div class="actionBtn">
                            <a href="/edit/${s._id}" class="edit">Edit</a>
                            <a @click=${onDelete} href="javascript:void(0)" class="remove">Delete</a>
                        </div>`
                    : nothing
                    }
                </div>
            </div>
        </section>
`;

// function control(pet, hasUser, canDonate, isOwner, onDelete, onDonate) {
//     if (hasUser == false) {
//         return '';
//     }
//     if (canDonate) {
//         return html`
//         <div class="actionBtn">
//             <a @click=${onDonate} href="javascript:void(0)" class="donate">Donate</a>
//         </div>`;
//     }
//     if (isOwner) {
//         return html`
//         <div class="actionBtn">
//             <a href="/edit/${pet._id}" class="edit">Edit</a>
//             <a @click=${onDelete} href="javascript:void(0)" class="remove">Delete</a>
//         </div>`;
//     }
// }

export async function detailsShow(ctx) {
    let id = ctx.params.id;
    let subject = await getById(id);
    let isOwner = subject._ownerId === ctx.user._id;



    ctx.render(template(subject, isOwner, onDelete));
    // let requests = [
    //     getById(id),
    //     getDonation(id)
    // ];

    // let hasUser = Boolean(ctx.user);
    // if (hasUser) {
    //     requests.push(getOwnDonation(id, ctx.user._id));
    // }
    // let [pet, donations, hasDonation] = await Promise.all(requests);

    // let isOwner = hasUser && ctx.user._id == pet._ownerId;
    // let canDonate = !isOwner && hasDonation == 0;

    async function onDelete() {
        let choice = confirm('Are you sure you want to delete it?');

        if (choice) {
            await delById(id);
            ctx.page.redirect('/catalog');
        }
    }

    // async function onDonate() {
    //     await donate(id);
    //     ctx.page.redirect('/catalog/' + id);
    // }
}