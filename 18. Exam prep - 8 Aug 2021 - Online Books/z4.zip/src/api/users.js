import { clearUserData, setUserData } from "../util.js";
import { get, post, put, del } from "./api.js";

// Login
export async function login(email, password) {
    let { _id, email: resE, accessToken } = await post('/users/login', { email, password });

    setUserData({
        _id,
        email: resE,
        accessToken,
    });
}

// Register
export async function register(email, password) {
    let { _id, email: resE, accessToken } = await post('/users/register', { email, password });

    setUserData({
        _id,
        email: resE,
        accessToken,
    });
}

// Logout
export function logout() {
    get('/users/logout');
    clearUserData();
}