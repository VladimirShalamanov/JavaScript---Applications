import { getAllForMyBooks } from '../api/data.js';
import { html, nothing } from '../lib.js';

let template = (arr) => html`
<section id="my-books-page" class="my-books">
    <h1>My Books</h1>
    <!-- Display ul: with list-items for every user's books (if any) -->
    <!-- Display paragraph: If the user doesn't have his own books  -->
    <ul class="my-books-list">
        ${arr.length == 0 ?
        html`<p class="no-books">No books in database!</p>`
        : arr.map(a => html`
        <li class="otherBooks">
            <h3>${a.title}</h3>
            <p>Type: ${a.type}</p>
            <p class="img"><img src=${a.imageUrl}></p>
            <a class="button" href="/details/${a._id}">Details</a>
        </li>
        `)}
        
    </ul>
</section>
`;

export async function myBooksShow(ctx) {
  let arr = await getAllForMyBooks(ctx.user._id);

  ctx.render(template(arr));
}