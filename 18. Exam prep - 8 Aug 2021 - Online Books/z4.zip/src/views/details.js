import { delById, getById, addData, getTotalData, hasClicked } from '../api/data.js';
import { html, nothing } from '../lib.js';
import { createSubmit } from '../util.js';

// @click=${onDelete}   javascript:void(0)
let template = (s, hasUser, isOwner, onDelete, likes, clicked, onLike) => html`
<section id="details-page" class="details">
    <div class="book-information">
        <h3>${s.title}</h3>
        <p class="type">Type: ${s.type}</p>
        <p class="img"><img src=${s.imageUrl}></p>
        <div class="actions">
            ${isOwner ?
            html`
              <!-- Edit/Delete buttons ( Only for creator of this book )  -->
              <a class="button" href="/edit/${s._id}">Edit</a>
              <a @click=${onDelete} class="button" href="javascript:void(0)">Delete</a>
            ` : nothing}

            ${hasUser && !isOwner && clicked == 0 ?
            html`
                <!-- Bonus -->
                <!-- Like button ( Only for logged-in users, which is not creators of the current book ) -->
                <a @click=${onLike} class="button" href="javascript:void(0)">Like</a>
              ` : nothing}

              <div class="likes">
                  <img class="hearts" src="/images/heart.png">
                  <span id="total-likes">Likes: ${likes}</span>
              </div>
              <!--${!isOwner ?html`-->
                <!-- ( for Guests and Users )  -->
                <!-- Bonus -->
                <!--` : nothing}-->
        </div>
    </div>
    <div class="book-description">
        <h3>Description:</h3>
        <p>${s.description}</p>
    </div>
</section>
`;

export async function detailsShow(ctx) {
  let id = ctx.params.id;
  let subject = await getById(id);
  let isOwner = ctx.user && subject._ownerId === ctx.user._id;

  let likes = await getTotalData(id);

  let clicked;
  if (ctx.user){
    clicked = await hasClicked(id, ctx.user._id);
  } 

  ctx.render(template(subject, ctx.user, isOwner, onDelete, likes, clicked, onLike));

  async function onDelete() {
    let choice = confirm('Are you sure you want to delete it?');

    if (choice) {
      await delById(id);
      ctx.page.redirect('/catalog');
    }
  }

  async function onLike() {
    await addData(id);
    likes = await getTotalData(id);
    clicked = await hasClicked(id, ctx.user._id);
    ctx.render(template(subject, ctx.user, isOwner, onDelete, likes, clicked, onLike));
  }
}