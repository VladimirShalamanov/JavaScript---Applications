import { logout } from "../api/users.js";
import { html, render, page } from "../lib.js";
import { getUserData } from "../util.js";

let nav = document.getElementById('site-header');

// javascript:void(0) + @click=${onLogout}
let navTemp = (hasUser) => html`
<nav class="navbar">
    <section class="navbar-dashboard">
        <a href="/catalog">Dashboard</a>
        ${!hasUser ?
        html`<!-- Guest users -->
            <div id="guest">
                <a class="button" href="/login">Login</a>
                <a class="button" href="/register">Register</a>
            </div>`
            : html`<!-- Logged-in users -->
            <div id="user">
                <span>Welcome, ${hasUser.email}</span>
                <a class="button" href="/mybooks">My Books</a>
                <a class="button" href="/create">Add Book</a>
                <a @click=${onLogout} class="button" href="javascript:void(0)">Logout</a>
            </div>`}
    </section>
</nav>
`;

export function updateNav() {
    let user = getUserData();

    render(navTemp(user), nav);
}

function onLogout() {
    logout();
    updateNav();
    page.redirect('/catalog');
}