import { getAll } from '../api/data.js';
import { html, nothing } from '../lib.js';

let template = (arr) => html`
<section id="dashboard-page" class="dashboard">
            <h1>Dashboard</h1>
            <!-- Display ul: with list-items for All books (If any) -->
            <!-- Display paragraph: If there are no books in the database -->
            <ul class="other-books-list">
            ${arr.length == 0 ?
            html`<p class="no-books">No books in database!</p>`
            : arr.map(a => html`
                <li class="otherBooks">
                    <h3>${a.title}</h3>
                    <p>Type: ${a.type}</p>
                    <p class="img"><img src=${a.imageUrl}></p>
                    <a class="button" href="/details/${a._id}">Details</a>
                </li>
            `)}
            </ul>
</section>
`;

export async function catalogShow(ctx) {
  let arr = await getAll();

  ctx.render(template(arr));
}